package com.bts.Home;


import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.effect.DropShadow;
import javafx.scene.effect.Shadow;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class Home extends Application{

    @Override
    public void start(Stage stage) {

        Image image = new Image("assets\\hitman2.jpg");
        ImageView imageView = new ImageView(image);

        DropShadow sh = new DropShadow();
        sh.setColor(Color.BLUEVIOLET);
        DropShadow sh2 = new DropShadow();
        sh2.setColor(Color.BLUE);
        
        imageView.setFitWidth(200);
        imageView.setPreserveRatio(true);
        VBox vb1 = new VBox(imageView);

        Text text1 = new Text("Name :- Rohit Sharma");
        Text text2 = new Text("Email :- sharma.r45@gmail.com");
        Label lb1 = new Label("Address :- Nagpur");
        
        text1.setFont(new Font(20));
        text2.setFont(new Font(20));

        //setting
        lb1.setFont(new Font(20));
        text2.setStyle("-fx-stroke:black");

        lb1.setEffect(sh);


        VBox vb2 = new VBox(10,text1,text2,lb1);

        vb1.setAlignment(Pos.BOTTOM_CENTER);

        HBox hb1 = new HBox(170,vb1,vb2);

                hb1.setAlignment(Pos.BOTTOM_CENTER);

        
        
        
        //hb2


        Text text3 = new Text("Skills:- ");
         text3.setEffect(sh2);

         Text text4 = new Text("Batting ");
        Text text5 = new Text("Off - Spin");
         Text text6 = new Text("Captain");
        // Text text2 = new Text("Email :- Captain Cool");kk
        text3.setStyle("-fx-stroke:black");
        text3.setFont(new Font(25));
        text4.setFont(new Font(20));
        text5.setFont(new Font(20));
        text6.setFont(new Font(20));
        VBox vb3 = new VBox(text3);
        
        VBox vb4 = new VBox(text4,text5,text6);
        HBox hb2 = new HBox(370,vb3,vb4);

//  hb2.setAlignment(Pos.BOTTOM_CENTER);
      
        

        // Hb3 

         Text text7 = new Text("Education:- ");

         text7.setEffect(sh2);

         Text text8 = new Text("SSC ");
        Text text9 = new Text("HSC");
         Text text10 = new Text("B-tech in Computer Science");
        // Text text2 = new Text("Email :- Captain Cool");kk
        text7.setStyle("-fx-stroke:black");
        text7.setFont(new Font(25));
        text9.setFont(new Font(20));
        text8.setFont(new Font(20));
        text10.setFont(new Font(20));
        VBox vb5 = new VBox(text7);
        
        VBox vb6 = new VBox(text8,text9,text10);
        HBox hb3 = new HBox(320,vb5,vb6);




// Hb3 

         Text text11 = new Text("Project:- ");
         text11.setEffect(sh2);
         


         Text text12 = new Text("PathFinders");
        Text text13 = new Text("Amazon Clone");
         Text text14 = new Text("Netflix Clone");
        // Text text2 = new Text("Email :- Captain Cool");kk
        text11.setStyle("-fx-stroke:black");
        text11.setFont(new Font(25));
        text12.setFont(new Font(20));
        text13.setFont(new Font(20));
        text14.setFont(new Font(20));

        VBox vb7 = new VBox(text11);
        
        VBox vb8 = new VBox(text14,text12,text13);
        HBox hb4 = new HBox(350,vb7,vb8);




        VBox  root = new VBox(50);
        // root.setBackground());
        
        //adding hb1  to root 
        root.getChildren().addAll(hb1);
        //adding hb2 to root
        root.getChildren().addAll(hb2);
        //adding hb3 to root
        root.getChildren().addAll(hb3);


        //adding hb4 to root
        root.getChildren().addAll(hb4);




        Scene scene = new Scene(root,800,800);
        scene.setFill(Color.YELLOW);
 
        stage.setScene(scene);
        stage.show();
        stage.setResizable(true);
       




    }
}