package com.structure;




import javafx.application.Application;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.effect.DropShadow;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.scene.image.*;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;

public class Home extends Application {
    @Override
    public void start(Stage myStage) throws Exception{
        /*Text tx1 = new Text(700,50,"Good Morning");
        tx1.setFill(Color.BLACK);
        Group gr = new Group(tx1);
        Scene myScene = new Scene(gr,1800,1000);
        myScene.setFill(Color.RED);
        myStage.setTitle("C2w");
        myStage.setWidth(1000);
        myStage.setHeight(800);
        myStage.setResizable(true);
        myStage.setScene(myScene);
        myStage.getIcons().add(new Image());
        myStage.show();*/

        Text tx1 = new Text(7000,50,"have a nice day");
        DropShadow ds = new DropShadow();
        ds.setColor(Color.YELLOW);
        Text tx2 = new Text(700,50,"GM");
        Group gr = new Group(tx1,tx2);
       // Label lb = new Label();
        //lb.setText("learning javaFx");
        tx2.setEffect(ds);
        tx2.setStyle("-fx-stroke: black;");
        tx2.setFont(new Font(30));
        tx2.setFill(Color.MAROON);
        VBox vb = new VBox(10);
        Image image = new Image("assets\\Image\\core2web.jpg");
        ImageView imageView = new ImageView(image);
        imageView.setFitWidth(200);
        imageView.setPreserveRatio(false);
        vb.getChildren().addAll(imageView);
        vb.setVisible(true);

        VBox vb2 = new VBox(15,tx1,tx2);
        HBox hb = new HBox(50,vb,vb2);
        Scene myScene = new Scene(hb, 1000, 800);
        myStage.setScene(myScene);
        myStage.show();


    }

    
   
}

