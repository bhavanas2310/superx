package com.seesion7;



import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class page2 {
    Scene p2Scene;
    Stage p2Stage;
    public void setP2Scene(Scene p2Scene) {
        this.p2Scene = p2Scene;
    }
    public void setP2Stage(Stage p2Stage) {
        this.p2Stage = p2Stage;
    }

    public VBox createScene(Runnable back){
        Text tx = new Text("Second Page");
        Button pvrButton = new Button("Previou Button");
        pvrButton.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent arg0) {
                back.run();
            }
            
        });

        VBox vb = new VBox(50,tx,pvrButton);
        vb.setStyle("-fx-alignment : top_center");
        return vb;
        
    }
    
    
    
}
    

