package com.session11;


import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public  class Page1 extends Application  {

    Stage primaryStage;
    Scene page1Scene,page2Scene;

    private void initialize(){

        Page2 page2 = new Page2();
        page2.setStage(primaryStage);
        page2Scene = new Scene(page2.createScene(this::handleBackButton),800,700);
        page2.setScene(page2Scene);
    }


    @Override
    public void start(Stage stage) throws Exception {

        Text txt  = new Text("Page1");
        Button btn = new Button("Next Page");
        btn.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent arg0) {
                initialize();
                primaryStage.setScene(page2Scene);
            }
            
        });

        VBox vb = new VBox(50,txt,btn);
        vb.setStyle("-fx-background-color:lightblue");
        vb.setAlignment(Pos.CENTER);
        Scene sc = new Scene(vb,800,700);
        
        stage.setScene(sc);
        page1Scene = sc;
        primaryStage = stage;
        stage.show();

        
    }

    private void handleBackButton(){
        primaryStage.setScene(page1Scene);
    }
    
}

    

