package com.session11;

import javafx.application.Application;

public class Main {
    public static void main(String[] args) {
        System.out.println("Hello world!");
        Application.launch(Page1.class,args);


        StudentInfoPojo stu1 = new StudentInfoPojo();

      
    }
}