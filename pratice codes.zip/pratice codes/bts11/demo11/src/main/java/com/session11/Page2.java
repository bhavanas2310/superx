package com.session11;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class Page2 {
    
    Stage stage;
     Scene scene;
     VBox vbox;
   
   
     public VBox createScene(Runnable back){

        Text txt = new Text("Second Page");
        Button prvBtn = new Button("Previos");

        prvBtn.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent arg0) {
                back.run();
                
            }
            
        });
        VBox vb = new VBox(50,txt,prvBtn);
                vb.setStyle("-fx-background-color:orange");
                vb.setAlignment(Pos.CENTER);

        return vb;

     }
   
     public VBox getVbox() {
        return vbox;
    }
     public void setVbox(VBox vbox) {
         this.vbox = vbox;
     }
    public Stage getStage() {
        return stage;
    }
    public void setStage(Stage stage) {
        this.stage = stage;
    }
    public Scene getScene() {
        return scene;
    }
    public void setScene(Scene scene) {
        this.scene = scene;
    }
   
}
