package com.session12;

    





import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class Home extends Application {
    int square;
    int sqrt;
    Text result = new Text();

    

    @Override
    public void start(Stage stage) throws Exception {

        Text name=new Text();
        TextField tf=new TextField();
        tf.setFocusTraversable(false);
        tf.setPromptText("Enter Number:");

        
        Button btn=new Button("Square");
        btn.setFocusTraversable(false);
        btn.setStyle("-fx-background-color:Blue ; -fx-text-fill:White");

        Button btn1=new Button("Square Root");
        btn1.setFocusTraversable(false);
        btn1.setStyle("-fx-background-color:Blue ; -fx-text-fill:White");
        
        
        
        btn.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                try {
                    int num = Integer.parseInt(tf.getText());
                    int square = num * num;
                    result.setText("Square: " + square);
                } catch (NumberFormatException e) {
                    result.setText("Please enter a valid number!");
                }
            }
        });

       

         btn1.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                try {
                    double num = Double.parseDouble(tf.getText());
                    if (num < 0) {
                        result.setText("Square root of negative number is not real.");
                    } else {
                        double sqrt = Math.sqrt(num);
                        result.setText("Square Root: " + String.format("%.3f", sqrt));
                    }
                } catch (NumberFormatException e) {
                    result.setText("Please enter a valid number!");
                }
            }
        });

        if(btn.onMouseClickedProperty() != null){
            
        }


        VBox vb=new VBox(50, name,tf,btn,btn1,result);
        vb.setPadding(new Insets(100, 100, 100, 100));
        vb.setStyle("-fx-background-color:green");
           
        
        Scene sc1=new Scene(vb);

        sc1.setFill(Color.YELLOW);

        stage.setTitle("Core2Web");
        stage.setScene(sc1);
        stage.setResizable(true);
        


        stage.show();
    }
    
    
}