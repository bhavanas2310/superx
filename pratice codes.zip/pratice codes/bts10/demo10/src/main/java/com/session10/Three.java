package com.session10;



import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.Button;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;

public class Three {
    public VBox createScene(Runnable back){
        

Text txt = new Text("Three");
Button btn = new Button("home");


btn.setOnAction(new EventHandler<ActionEvent>() {

    @Override
    public void handle(ActionEvent arg0) {
        back.run();
    }
    
});
        VBox vb = new VBox(50,txt,btn);





        return vb;
    }
    
}


    

