package loginnavigation;

import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.image.ImageView;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;

public class Login extends Application {
    
   
    Stage primaryStage;
    Scene loginScene,homeScene,exploreScene;
    String u_Name = "mahi";
    String p_key  = "ziva";

    
    public void start(Stage stage){

        VBox vb = new VBox(40);


        ImageView logo = new ImageView(new Image("Assetes\\wallpaper.jpg"));

        logo.setFitHeight(150);
        logo.setPreserveRatio(true);
        Text txt  = new Text("LOGIN");
        Label error_msg = new Label("");


        TextField username = new TextField();
        username.setPromptText("enter user name");

        username.setMaxWidth(200);

        PasswordField password = new PasswordField();
        password.setPromptText("enter password");
        password.setMaxWidth(200);



        Button loginBtn = new Button("Login");
        Button exploreBtn = new Button("Explore");

        loginBtn.setOnAction(e->{

            if(u_Name.equals(username.getText()) && p_key.equals(password.getText())){
                error_msg.setText("");

                System.out.println("Home Clicked");
                //initialize home page
                initializeHome();
                
                //set home  scene

                primaryStage.setScene(homeScene);
                System.out.println("Home Scene set");


            }else{

                //show invalid details
                error_msg.setText("Invalid Credentials!");


            }


        });


        exploreBtn.setOnAction(e->{

            initializeExplore();

            primaryStage.setScene(exploreScene);

        });






        vb.setStyle("-fx-background-color:lightblue");

        vb.getChildren().addAll(logo,txt,username,password,loginBtn,exploreBtn,error_msg);

        vb.setAlignment(Pos.CENTER);


        Scene sc = new Scene(vb,1080,720);

        loginScene = sc;
        primaryStage = stage;
        primaryStage.setScene(loginScene);


        primaryStage.show();


        





    }

    private void initializeHome(){

        Home homePage = new Home();
        homeScene = new Scene(homePage.createHomeScene(this::back),1080,720);
        
        // homeScene = new Scene(homePage.createHomeScene(()->{}),1080,720);
        homePage.setHomeStage(primaryStage);
        homePage.setHomeScene(homeScene);



    }
    private void initializeExplore(){

        Explore explorePage = new Explore();
        exploreScene = new Scene(explorePage.createExploreScene(this::back),1080,720);
        
        // homeScene = new Scene(homePage.createHomeScene(()->{}),1080,720);
        explorePage.setExploreStage(primaryStage);
        explorePage.setExploreScene(exploreScene);



    }

    public void back(){

        primaryStage.setScene(loginScene);

    }
    
}
