package loginnavigation;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class Explore {

    Stage exploreStage;
    Scene exploreScene;
    public Stage getExploreStage() {
        return exploreStage;
    }
    public void setExploreStage(Stage exploreStage) {
        this.exploreStage = exploreStage;
    }
    public Scene getExploreScene() {
        return exploreScene;
    }
    public void setExploreScene(Scene exploreScene) {
        this.exploreScene = exploreScene;
    }

    public VBox createExploreScene(Runnable back){

        VBox vb = new VBox(40);

        Button backButton = new Button("Back");

        backButton.setOnAction(
            e->{

                back.run();

            }
        );



        vb.getChildren().add(backButton);
        vb.setAlignment(Pos.CENTER);

        return vb;


    }


    
}
