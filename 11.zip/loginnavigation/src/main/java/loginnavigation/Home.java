package loginnavigation;

import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class Home {

    public Stage getHomeStage() {
        return homeStage;
    }

    public void setHomeStage(Stage homeStage) {
        this.homeStage = homeStage;
    }

    public Scene getHomeScene() {
        return homeScene;
    }

    public void setHomeScene(Scene homeScene) {
        this.homeScene = homeScene;
    }

    public Scene getExploreScene() {
        return exploreScene;
    }

    public void setExploreScene(Scene exploreScene) {
        this.exploreScene = exploreScene;
    }

    Stage homeStage;
    Scene homeScene,exploreScene;

    public VBox createHomeScene(Runnable backToLogin){

        VBox vb = new VBox(40);



        Button exploreBtn = new Button("Explore");



        exploreBtn.setOnAction(e->{
            Explore explorePage = new Explore();

            Scene sc = new Scene(explorePage.createExploreScene(this::back),1080,720);

            exploreScene = sc;


            explorePage.setExploreStage(homeStage);
            explorePage.setExploreScene(sc);

            homeStage.setScene(exploreScene);

            

        });

        Button backBtn = new Button("Back");

        backBtn.setOnAction(e->{
            backToLogin.run();

        });



        vb.getChildren().addAll(exploreBtn,backBtn);

        vb.setStyle("-fx-background-color:blue");
        vb.setAlignment(Pos.CENTER);
        


        return vb;


       
        
    }

    public void back(){

        homeStage.setScene(homeScene);

    }

    
    
}
