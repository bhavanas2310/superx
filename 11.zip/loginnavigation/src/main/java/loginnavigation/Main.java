package loginnavigation;

import javafx.application.Application;

public class Main {
    public static void main(String[] args) {
        System.out.println("Client Class (Main)");
        Application.launch(Login.class,args);

    }
}